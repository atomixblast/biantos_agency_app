╔══════════════════════════════════════════════════════════╗
║                                                          ║
║           🏢 BIANTOS AGENCY v1.0.0                  ║
║              Gestion de Commandes                        ║
║                                                          ║
╚══════════════════════════════════════════════════════════╝

📖 INSTALLATION RAPIDE
══════════════════════

1️⃣  Extraire ce ZIP dans un dossier de votre choix

2️⃣  Double-cliquer sur : install_windows.bat

3️⃣  Suivre les instructions à l'écran

4️⃣  Lancer l'application avec : start_biantos.bat

═══════════════════════════════════════════════════════════

⚠️  PRÉREQUIS
═════════════

Python 3.10 ou supérieur doit être installé sur votre PC.

📥 Télécharger Python : https://www.python.org/downloads/

⚠️  IMPORTANT : Cochez "Add Python to PATH" lors de l'installation !

═══════════════════════════════════════════════════════════

📁 CONTENU DU PACKAGE
═════════════════════

✓ Application Django complète
✓ Script d'installation automatique
✓ Documentation complète
✓ Tous les fichiers nécessaires

═══════════════════════════════════════════════════════════

🆘 BESOIN D'AIDE ?
═════════════════

Consultez le fichier : INSTALLATION_WINDOWS.md

═══════════════════════════════════════════════════════════

© 2024 Biantos - Version 1.0.0
